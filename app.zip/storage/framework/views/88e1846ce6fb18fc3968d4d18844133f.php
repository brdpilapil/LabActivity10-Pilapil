

<?php $__env->startSection('title', 'Barangay Bulletin - Purok [Lastname]'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6 bg-white p-4 rounded-lg shadow sm:p-6">
    <form method="GET" action="<?php echo e(route('posts.index')); ?>" class="flex flex-col sm:flex-row gap-3">
        <input 
            type="text" 
            name="q" 
            value="<?php echo e(request('q')); ?>" 
            placeholder="Search title..." 
            class="border border-gray-300 rounded px-3 py-2 w-full sm:w-1/2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
        
        <select 
            name="category" 
            class="border border-gray-300 rounded px-3 py-2 w-full sm:w-1/3 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
            <option value="">All Categories</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c); ?>" <?php echo e(request('category') === $c ? 'selected' : ''); ?>>
                    <?php echo e($c); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <button type="submit" class="bg-blue-700 text-white px-5 py-2 rounded hover:bg-blue-800 transition">
            Filter
        </button>
    </form>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
<?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="bg-white rounded-lg shadow p-5 flex flex-col justify-between border-t-4 <?php echo e($post->is_pinned ? 'border-amber-500' : 'border-blue-600'); ?>">
        <div>
            <div class="flex items-center justify-between mb-2">
                <span class="text-xs font-semibold px-2.5 py-0.5 rounded bg-blue-100 text-blue-800">
                    <?php echo e($post->category); ?>

                </span>
                <?php if($post->is_pinned): ?>
                    <span class="text-xs font-bold px-2 py-0.5 rounded bg-amber-500 text-white">
                        Pinned
                    </span>
                <?php endif; ?>
            </div>

            <h2 class="text-lg font-bold text-gray-900 mb-2">
                <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="hover:text-blue-600">
                    <?php echo e($post->title); ?>

                </a>
            </h2>

            <p class="text-gray-600 text-sm line-clamp-3 mb-4">
                <?php echo e($post->body); ?>

            </p>
        </div>

        <div class="text-xs text-gray-500 border-t pt-3 flex justify-between items-center">
            <span>Author ID: <?php echo e($post->author_id); ?></span>
            <span>Views: <?php echo e($post->views); ?></span>
            <span><?php echo e($post->published_at ? $post->published_at->format('M d, Y') : 'N/A'); ?></span>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-span-full bg-white p-6 text-center text-gray-500 rounded-lg shadow">
        <p>No posts match your search.</p>
    </div>
<?php endif; ?>
</div>

<div class="mt-4">
    <?php echo e($posts->links()); ?>

</div>

<p class="text-sm text-gray-600 mt-2">
    Showing <?php echo e($posts->firstItem() ?? 0); ?>-<?php echo e($posts->lastItem() ?? 0); ?> of <?php echo e($posts->total()); ?> posts
</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\LabActivity10-Pilapil\resources\views/posts/index.blade.php ENDPATH**/ ?>